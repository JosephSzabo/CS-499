package com.zybooks.josephszaboapp;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText nameText;
    private Button buttonSayHello;
    private TextView textGreeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the views
        nameText = findViewById(R.id.nameText);
        buttonSayHello = findViewById(R.id.buttonSayHello);
        textGreeting = findViewById(R.id.textGreeting);

        //Disable button on startup
        buttonSayHello.setEnabled(false);

        // Add a text change listener to the nameText field
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence,int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                // Enable or disable the button depending on nameText being empty or not
                buttonSayHello.setEnabled(charSequence.length() > 0);
            }
            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
    }

        //Define the sayHello() function
        public void SayHello(View view) {
            //Get the name entered by the user
            String name = nameText.getText().toString();

            //Check whether nameText is empty or not
            if (!name.isEmpty()) {
                //Display greeting message
                textGreeting.setText("Hello, " + name + "!");
            } else {
                // Else return from the function is nameText is empty
                return;
            }

        }
}